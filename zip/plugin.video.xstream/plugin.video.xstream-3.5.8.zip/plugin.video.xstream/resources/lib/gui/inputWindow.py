import xbmc
import xbmcgui

class cInputWindow(xbmcgui.WindowDialog):
   def __init__(self, *args, **kwargs):
      self.cptloc = kwargs.get('captcha')
      self.img = xbmcgui.ControlImage(335,30,624,60,self.cptloc)
      self.addControl(self.img)
      self.kbd = xbmc.Keyboard()

   def get(self):
      self.show()
      self.kbd.doModal()
      if (self.kbd.isConfirmed()):
         text = self.kbd.getText()
         self.close()
         return text
      self.close()
      return False